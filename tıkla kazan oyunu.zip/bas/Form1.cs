using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using System.Drawing.Imaging;
using System.Net.Sockets;

namespace bas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button2_Click(object sender, EventArgs e)
        {


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            BackgroundImage = pictureBox1.Image;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            BackgroundImage = pictureBox1.Image;
        }


        private int puan = 0;

        private void button1_Click_1(object sender, EventArgs e)
        {
            puan += 1; // Puan� 1 artt�ran �ey
            label1.Text = puan.ToString();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

